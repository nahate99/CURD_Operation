package com.curd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curd.model.Employee;
import com.curd.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class ManageEmployeeProfile {

	@Autowired
	private EmployeeService employeeService;

	// create employee record.
	@PostMapping(value = "/create-employee-record", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> createEmployeeResource(@RequestBody Employee employee) {
		Employee createdEmployee = employeeService.createEmployee(employee);
		return new ResponseEntity<>(createdEmployee, HttpStatus.CREATED);
	}

	// read employees data
	@GetMapping(value = "/read-data", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Employee>> readEmployeeResource() {
		List<Employee> emptData = employeeService.findEmployeeData();
		return new ResponseEntity<>(emptData, HttpStatus.OK);

	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteEmployeeById(@PathVariable("id") int id) {
		boolean flag = employeeService.deleteByEmpId(id);
		if (flag) {
			return new ResponseEntity<String>("Employee  deleted sucessfully !!!", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Employee could not be  deleted due to some network issue ::::",
					HttpStatus.BAD_REQUEST);
		}
	}

	@PatchMapping("/update")
	public ResponseEntity<?> updateEmployee(@RequestBody Employee employee) {
		employeeService.updateEmployee(employee);
		return new ResponseEntity<>("Employee record is updated !!!", HttpStatus.OK);

	}

}
