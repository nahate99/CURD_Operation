package com.curd.service;

import java.util.List;

import com.curd.model.Employee;

public interface EmployeeService {

	Employee createEmployee(Employee employee);

	List<Employee> findEmployeeData();

	boolean deleteByEmpId(int id);

	void updateEmployee(Employee employee);

}
